'use client'
import TextField from '@/app/component/inputfield'
import CustomLabel from '@/app/component/label'
import Layout from '@/app/component/layout'
import Colors from '@/app/utils/colors'
import { useRouter } from 'next/navigation'
import React, { useEffect, useState } from 'react'
import { getCompanyById } from '../dashboard-page/dashboard'
import { toast } from 'react-toastify'

const Customer = () => {
  const [customerType, setType] = useState('Business')
  const [contacts, setContacts] = useState([{ salutation: '', firstName: '', lastName: '', email: '', workPhone: '', mobile: '' }])

  const updateContact = (index: number, field: string, value: string) => {
    const updated = [...contacts]
    updated[index][field as keyof typeof updated[0]] = value
    setContacts(updated)
  }

  const addContact = () => {
    setContacts([...contacts, { salutation: '', firstName: '', lastName: '', email: '', workPhone: '', mobile: '' }])
  }

  const removeContact = (index: number) => {
    const updated = [...contacts]
    updated.splice(index, 1)
    setContacts(updated)
  }
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const states = ['Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh', 'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jharkhand', 'Karnataka', 'Kerala', 'Madhya Pradesh']
  const cities = ['Ahmedabad', 'Surat', 'Baroda', 'Rajkot', 'Bhavnagar', 'Jamnagar', 'Junagadh', 'Gandhinagar', 'Porbandar', 'Morbi', 'Nadiad', 'Bharuch', 'Vapi', 'Ankleshwar', 'Patan', 'Mehsana', 'Bhuj', 'Palanpur', 'Veraval', 'Surendranagar']
  const [customerReg, setRegDetails] = useState({salutation:'', firstName:'', lastName:'',  companyName:'',displayName:'', email:'', workPhone:'', mobileNo:'',pan:'', billingAttention: '', billingAddressLine1: '', billingAddressLine2: '', billingCity: '', billingState: '', billingPincode: '', billingPhone: '', shippingAttention: '', shippingAddressLine1: '', shippingAddressLine2: '', shippingCity: '', shippingState: '', shippingPincode: '', shippingPhone: '' })

  const [sameAsBilling, setSameAsBilling] = useState(false)

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const checked = e.target.checked
    setSameAsBilling(checked)

    if (checked) {
      setRegDetails(prev => ({
        ...prev,
        shippingAttention: prev.billingAttention,
        shippingAddressLine1: prev.billingAddressLine1,
        shippingAddressLine2: prev.billingAddressLine2,
        shippingCity: prev.billingCity,
        shippingState: prev.billingState,
        shippingPincode: prev.billingPincode,
        shippingPhone: prev.billingPhone, // you had mistakenly used `shippingPincode` here
      }))
    } else {
      setRegDetails(prev => ({
        ...prev,
        shippingAttention: '',
        shippingAddressLine1: '',
        shippingAddressLine2: '',
        shippingCity: '',
        shippingState: '',
        shippingPincode: '',
        shippingPhone: '',
      }))
    }
  }

  useEffect(() => {
    getCompanyDetails();
  }, []);

  const getCompanyDetails = async () => {
    try {

      const localCompanyId = localStorage.getItem('selectedCompanyId');
      if (!localCompanyId) {
        return;
      }

      const res = await getCompanyById(localCompanyId);
      console.log("===response data", res.data)
      if (res.success) {
        setRegDetails({...customerReg,companyName: res.data.companyName })
      } else {
        
      }
    } catch (err: any) {
      toast.error(err.toString())
    } 
  };

  return (
    <Layout>
      <div className='w-full flex flex-col items-center'>
        <h1 className='text-3xl font-bold text-center text-black mb-10'>Customer Registration</h1>

        <div className='w-[95%] border rounded-md bg-white p-5'>

          {/* Row 1: Customer Type */}
          <div className='grid grid-cols-1 md:grid-cols-4 gap-4 mb-3'>
            <div className='col-span-1 md:col-span-1'>
              <div className="flex items-center gap-3">
                <div className="min-w-[120px]">
                  <CustomLabel title="Customer Type" />
                </div>
                <label className="flex items-center gap-1">
                  <input
                    type="radio"
                    name="customerType"
                    value="Business"
                    checked={customerType === 'Business'}
                    onChange={(e) => setType(e.target.value)}
                  />
                  Business
                </label>
                <label className="flex items-center gap-1">
                  <input
                    type="radio"
                    name="customerType"
                    value="Individual"
                    checked={customerType === 'Individual'}
                    onChange={(e) => setType(e.target.value)}
                  />
                  Individual
                </label>
              </div>
            </div>
          </div>

          {/* <div className="relative border p-4 rounded mb-4" style={{ border: Colors.borderColor }}>
            <span className="absolute -top-2 left-3 bg-white px-2 text-sm font-medium" style={{ color: Colors.labelColor }}>
              Primary Contact
            </span>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className='col-span-1'>
                <CustomLabel title="Salutation" />
                <select className="w-full border rounded-md px-3 py-2 text-sm">
                  <option value="">Select</option>
                  <option value="Mr.">Mr.</option>
                  <option value="Mrs.">Mrs.</option>
                  <option value="Ms.">Ms.</option>
                  <option value="Dr.">Dr.</option>
                </select>
              </div>

              <div className='col-span-1'>
                <TextField label='First Name' />
              </div>

              <div className='col-span-1'>
                <TextField label='Last Name' />
              </div>
            </div>
          </div> */}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-3">
            <div className='col-span-1'>
              <CustomLabel title="Salutation" />
              <select className="w-full border rounded-md px-3 py-2 text-sm">
                <option value="">Select</option>
                <option value="Mr.">Mr.</option>
                <option value="Mrs.">Mrs.</option>
                <option value="Ms.">Ms.</option>
                <option value="Dr.">Dr.</option>
              </select>
            </div>

            <div className='col-span-1'>
              <TextField label='First Name' name='firstName'/>
            </div>

            <div className='col-span-1'>
              <TextField label='Last Name' name='lastName'/>
            </div>
          </div>
          <div className='grid grid-cols-1 md:grid-cols-3 gap-3'>
            <div className='col-span-1 md:col-span-1'>
              <TextField label='Company Name' name='companyName' value={customerReg.companyName} onChange={(e)=> setRegDetails({...customerReg, companyName: e.target.value})} disabled={true}/>
            </div>
            <div className='col-span-1 md:col-span-1'>
              <TextField label='Display Name'  name='displayName'/>
            </div>
            <div className='col-span-1 md:col-span-1'>
              <TextField label='Email' name='email' />
            </div>
            <div className='col-span-1 md:col-span-1'>
              <TextField label='Work Phone' name='phone'/>
            </div>
            <div className='col-span-1 md:col-span-1'>
              <TextField label='Mobile Number' name='mobile'/>
            </div>
            <div className='col-span-1 md:col-span-1'>
              <TextField label='PAN'name='pan' />
            </div>
          </div>
          <div className="mt-3">
            <h2 className="text-base mb-1">Contact Persons</h2>
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm border border-gray-200 rounded overflow-hidden">
                <thead className="bg-gray-100">
                  <tr className="text-sm">
                    <td className="px-3 py-2">SALUTATION</td>
                    <td className="px-3 py-2">FIRST NAME</td>
                    <td className="px-3 py-2">LAST NAME</td>
                    <td className="px-3 py-2">EMAIL</td>
                    <td className="px-3 py-2">WORK PHONE</td>
                    <td className="px-3 py-2">MOBILE</td>
                    <td className="px-3 py-2 w-10"></td>
                  </tr>
                </thead>
                <tbody>
                  {contacts.map((contact, index) => (
                    <tr key={index} className="border-t border-gray-200">
                      <td className="px-3 py-2">
                        <select
                          value={contact.salutation}
                          onChange={(e) => updateContact(index, 'salutation', e.target.value)}
                          className="w-full border border-gray-300 rounded px-2 py-1"
                        >
                          <option value="">Select</option>
                          <option value="Mr.">Mr.</option>
                          <option value="Mrs.">Mrs.</option>
                          <option value="Ms.">Ms.</option>
                          <option value="Dr.">Dr.</option>
                        </select>
                      </td>
                      <td className="px-3 py-2">
                        <input type="text" className="w-full border border-gray-300 rounded px-2 py-1"
                          value={contact.firstName}
                          onChange={(e) => updateContact(index, 'firstName', e.target.value)}
                        />
                      </td>
                      <td className="px-3 py-2">
                        <input type="text" className="w-full border border-gray-300 rounded px-2 py-1"
                          value={contact.lastName}
                          onChange={(e) => updateContact(index, 'lastName', e.target.value)}
                        />
                      </td>
                      <td className="px-3 py-2">
                        <input type="email" className="w-full border border-gray-300 rounded px-2 py-1"
                          value={contact.email}
                          onChange={(e) => updateContact(index, 'email', e.target.value)}
                        />
                      </td>
                      <td className="px-3 py-2">
                        <input type="text" className="w-full border border-gray-300 rounded px-2 py-1"
                          value={contact.workPhone}
                          onChange={(e) => updateContact(index, 'workPhone', e.target.value)}
                        />
                      </td>
                      <td className="px-3 py-2">
                        <input type="text" className="w-full border border-gray-300 rounded px-2 py-1"
                          value={contact.mobile}
                          onChange={(e) => updateContact(index, 'mobile', e.target.value)}
                        />
                      </td>
                      <td className="text-center">
                        <button onClick={() => removeContact(index)} className="text-red-500 text-sm hover:underline">✖</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <button
              onClick={addContact}
              className="mt-4 flex items-center gap-2 px-4 py-2 text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-md text-sm"
            >
              Add Contact Person
            </button>

          </div>
          <h2 className="text-base mb-1 mt-3">Address</h2>
          <div className='w-full mb-3'>
            <h1 className='underline text-sm'>Billing Address</h1>
            <div className='mt-2 grid grid-cols-3 gap-x-4 gap-y-2'>
              <div className="sm:col-span-1">
                <CustomLabel title='Attention' />
                <div className="mt-1">
                  <input type="text" name="billingAttention" autoComplete="given-name" value={customerReg.billingAttention} onChange={(e) => { setRegDetails({ ...customerReg, billingAttention: e.target.value }) }} className="block w-full font-inter rounded-md border focus:outline-none border-gray-300 py-1 px-2 text-gray-900 focus:border-blue-500 focus:border-[2px] placeholder:text-gray-400 sm:text-sm sm:leading-6" />
                </div>
              </div>
              <div className="sm:col-span-1">
                <CustomLabel title='Address Line 1' />
                <div className="mt-1">
                  <input type="address" name="billingAddressLine1" autoComplete="given-name" value={customerReg.billingAddressLine1} onChange={(e) => { setRegDetails({ ...customerReg, billingAddressLine1: e.target.value }) }} className="block w-full font-inter rounded-md border focus:outline-none border-gray-300 py-1 px-2 text-gray-900 focus:border-blue-500 focus:border-[2px] placeholder:text-gray-400 sm:text-sm sm:leading-6" />
                </div>
              </div>
              <div className="sm:col-span-1">
                <CustomLabel title='Address Line 2' />
                <div className="mt-1">
                  <input type="address" name='billingAddressLine2' autoComplete="given-name" value={customerReg.billingAddressLine2} onChange={(e) => { setRegDetails({ ...customerReg, billingAddressLine2: e.target.value }) }} className="block w-full font-inter rounded-md border focus:outline-none border-gray-300 py-1 px-2 text-gray-900 focus:border-blue-500 focus:border-[2px] placeholder:text-gray-400 sm:text-sm sm:leading-6" />
                </div>
              </div>
              <div className="sm:col-span-1">
                <CustomLabel title='City' />
                <div className="relative w-full mt-1">
                  <select
                    value={customerReg.billingCity}
                    onChange={(e) => { setRegDetails({ ...customerReg, billingCity: e.target.value }) }}
                    name='billingCity'
                    className="block w-full rounded-md border focus:outline-none border-gray-300 py-2 px-2 text-gray-900 focus:border-blue-500 focus:border-[2px] placeholder:text-gray-400 sm:text-sm sm:leading-6 font-inter"
                  >
                    <option value="">Select City</option>
                    {cities.map((city: string, index: number) => (
                      <option key={index} value={city}>
                        {city}
                      </option>
                    ))}
                  </select>
                </div>

              </div>
              <div className="sm:col-span-1">
                <CustomLabel title='State' />
                <div className="relative w-full mt-1">
                  <select
                    value={customerReg.billingState}
                    onChange={(e) => { setRegDetails({ ...customerReg, billingState: e.target.value }) }}
                    name='billingState'
                    className="block w-full rounded-md border focus:outline-none border-gray-300 py-2 px-2 text-gray-900 focus:border-blue-500 focus:border-[2px] placeholder:text-gray-400 sm:text-sm sm:leading-6 font-inter"
                  >
                    <option value="">Select State</option>
                    {states.map((state: string, index: number) => (
                      <option key={index} value={state}>
                        {state}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="sm:col-span-1">
                <CustomLabel title='Pincode' />
                <div className="mt-1">
                  <input type="number" name='pincode1' autoComplete="given-name" value={customerReg.billingPincode} onChange={(e) => { setRegDetails({ ...customerReg, billingPincode: e.target.value }) }} className="block w-full font-inter rounded-md border focus:outline-none border-gray-300 py-1 px-2 text-gray-900 focus:border-blue-500 focus:border-[2px] placeholder:text-gray-400 sm:text-sm sm:leading-6" />
                </div>
              </div>
            </div>

            {/* Shipping Address */}
            <h1 className='underline text-sm mt-4'>Shipping Address</h1>
            <div className="mt-2 mb-3 flex items-center gap-2">
              <input type="checkbox" id="sameAsBilling" checked={sameAsBilling} onChange={handleCheckboxChange} />
              <label htmlFor="sameAsBilling" className="font-inter text-sm text-gray-700">Same as Billing Address</label>
            </div>
            <div className='mt-3 grid grid-cols-3 gap-x-4 gap-y-2'>
              <div className="sm:col-span-1">
                <CustomLabel title='Attention' />
                <div className="mt-1">
                  <input type="text" name="billingAttention" autoComplete="given-name" value={customerReg.shippingAttention} onChange={(e) => { setRegDetails({ ...customerReg, shippingAttention: e.target.value }) }} className="block w-full font-inter rounded-md border focus:outline-none border-gray-300 py-1 px-2 text-gray-900 focus:border-blue-500 focus:border-[2px] placeholder:text-gray-400 sm:text-sm sm:leading-6" />
                </div>
              </div>
              <div className="sm:col-span-1">
                <CustomLabel title='Address Line 1' />
                <div className="mt-1">
                  <input type="address" name='shippingAddressLine1' autoComplete="given-name" value={customerReg.shippingAddressLine1} onChange={(e) => { setRegDetails({ ...customerReg, shippingAddressLine1: e.target.value }) }} className="block w-full font-inter rounded-md border focus:outline-none border-gray-300 py-1 px-2 text-gray-900 focus:border-blue-500 focus:border-[2px] placeholder:text-gray-400 sm:text-sm sm:leading-6" />
                </div>
              </div>
              <div className="sm:col-span-1">
                <CustomLabel title='Address Line 2' />
                <div className="mt-1">
                  <input type="address" name='shippingAddressLine2' autoComplete="given-name" value={customerReg.shippingAddressLine2} onChange={(e) => { setRegDetails({ ...customerReg, shippingAddressLine2: e.target.value }) }} className="block w-full font-inter rounded-md border focus:outline-none border-gray-300 py-1 px-2 text-gray-900 focus:border-blue-500 focus:border-[2px] placeholder:text-gray-400 sm:text-sm sm:leading-6" />
                </div>
              </div>
              <div className="sm:col-span-1">
                <CustomLabel title='City' />
                <div className="relative w-full mt-1">
                  <select
                    value={customerReg.shippingCity}
                    onChange={(e) => { setRegDetails({ ...customerReg, shippingCity: e.target.value }) }}
                    name='shippingCity'
                    className="block w-full rounded-md border focus:outline-none border-gray-300 py-2 px-2 text-gray-900 focus:border-blue-500 focus:border-[2px] placeholder:text-gray-400 sm:text-sm sm:leading-6 font-inter"
                  >
                    <option value="">Select City</option>
                    {cities.map((city: string, index: number) => (
                      <option key={index} value={city}>
                        {city}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="sm:col-span-1">
                <CustomLabel title='State' />
                <div className="relative w-full mt-1">
                  <select
                    value={customerReg.shippingState}
                    onChange={(e) => { setRegDetails({ ...customerReg, shippingState: e.target.value }) }}
                    name='shippingState'
                    className="block w-full rounded-md border focus:outline-none border-gray-300 py-2 px-2 text-gray-900 focus:border-blue-500 focus:border-[2px] placeholder:text-gray-400 sm:text-sm sm:leading-6 font-inter"
                  >
                    <option value="">Select State</option>
                    {states.map((state: string, index: number) => (
                      <option key={index} value={state}>
                        {state}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="sm:col-span-1">
                <CustomLabel title='Pincode' />
                <div className="mt-1">
                  <input type="number" name='shippingPincode' autoComplete="given-name" value={customerReg.shippingPincode} onChange={(e) => { setRegDetails({ ...customerReg, shippingPincode: e.target.value }) }} className="block w-full font-inter rounded-md border focus:outline-none border-gray-300 py-1 px-2 text-gray-900 focus:border-blue-500 focus:border-[2px] placeholder:text-gray-400 sm:text-sm sm:leading-6" />
                </div>
              </div>
            </div>
            <div className="w-full flex items-center justify-center gap-5 pt-5">
              <button
                type="submit"
                disabled={isLoading}
                className="w-full md:w-auto bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg font-medium shadow-lg"
              >
                {'Submit'}
              </button>
              <button
                type="reset"
                className="w-full md:w-auto bg-[#03508C] text-white hover:bg-[#0874CB] px-6 py-2 rounded-lg font-medium shadow-lg"
                onClick={() => router.replace('/customer')}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  )
}

export default Customer
