export const ROUTES = {
    restore_item: '/items/restore',

    addState_state: '/database/state/add',
    restore_state:'/database/state/restore'
}