'use client';
import { useRouter } from 'next/navigation';
import { FaBuilding } from 'react-icons/fa';
import { MoreVertical } from 'lucide-react';
import Colors from '@/app/utils/colors';
import CustomButton from '../buttons/page';
import { CompanyData } from '@/app/(pages)/main-dashboard/company-list';



export default function OrganizationCard({ data }: { data: CompanyData }) {
    const router = useRouter();

    return (
        <div className="relative bg-white border rounded-2xl p-6 shadow-sm hover:shadow-lg transition-all">
            {/* {isDefault && (
                <div className="absolute top-0 left-0 bg-green-600 text-white text-xs px-2 py-0.5 rounded-br-xl rounded-tl-2xl">
                    DEFAULT
                </div>
            )} */}
            <div className="flex justify-between items-start">
                <div className="flex items-center gap-4">
                    <div className="bg-gray-100 p-4 rounded-lg">
                        <FaBuilding className="text-gray-600" size={32} />
                    </div>
                    <div>
                        <h3 className="text-lg font-semibold text-gray-800 font-inter">{data.companyName}</h3>
                        <p className="text-sm text-gray-600">
                            <span className="font-medium">Organization ID:</span> {data.companyId}
                        </p>
                        <p className="text-sm text-gray-600">
                            <span className="font-medium">Owner:</span> {data.ownerName}
                        </p>
                        <p className="text-sm text-gray-600">
                            <span className="font-medium">Industry:</span> {data.industry}
                        </p>
                        <p className="text-sm text-gray-600">
                            <span className="font-medium">Location:</span> {data.billingCity}, {data.billingState}
                        </p>
                        <p className="text-sm text-gray-600">
                            <span className="font-medium">GST:</span> {data.gstNumber}
                        </p>
                        <p className="text-xs text-gray-500">
                            Created on {new Date(data.createdAt).toLocaleDateString()}
                        </p>
                    </div>
                </div>
                {/* <button className="text-gray-500 hover:text-gray-700">
                    <MoreVertical size={18} />
                </button> */}
            </div>
            <div className="mt-4 text-right">
                {/* <CustomButton name='Go to Organization' className="text-white px-4 py-2 rounded-lg text-sm hover:bg-blue-700 transition font-inter" style={{ background: Colors.gradient2 }} onClick={() => router.push('/dashboard')} /> */}
                <CustomButton
                    name="Go to Organization"
                    className="text-white px-4 py-2 rounded-lg text-sm hover:bg-blue-700 transition font-inter"
                    style={{ background: Colors.gradient2 }}
                    onClick={() => {
                        console.log('Clicked!');
                        localStorage.setItem('selectedCompanyId', data.companyId.toString());
                        router.replace(`/dashboard-page?companyId=${data.companyId}`);
                    }}
                />
            </div>
        </div>
    );
}
