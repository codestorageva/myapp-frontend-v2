'use server'
import { SERVER_URL } from "@/core/constants"
import { API_ENDPOINTS } from "@/core/constants/api_endpoint"
import { apiServiceInstance } from "@/core/service/apis"
import { auth } from "../../../../auth"

export interface CompanyListResponse {
    success: boolean
    successCode: string
    pageNumber: number
    pageSize: number
    totalElements: number
    totalPages: number
    isLastPage: boolean
    data: CompanyData[]
  }
  
  export interface CompanyData {
    companyId: number
    companyName: string
    ownerName: string
    logo: string
    billingAddress1: string
    billingAddress2: string
    billingAddress3: string
    billingState: string
    billingCity: string
    billingPincode: string
    shippingAddress1: string
    shippingAddress2: string
    shippingAddress3: string
    shippingState: string
    shippingCity: string
    shippingPincode: string
    panNumber: string
    gstNumber: string
    serviceDescription: string
    industry: string
    status: boolean
    isDeleted: boolean
    createdAt: string
    updatedAt: string
    deletedAt: any
    bankDetails: BankDetail[]
    invoices: any[]
  }
  
  export interface BankDetail {
    bankId: number
    bankName: string
    ifscCode: string
    branch: string
    accountNumber: string
    accHolderName: string
    bankAddress: string
    status: boolean
    isDeleted: boolean
    createdAt: string
    updatedAt: string
    deletedAt: any
    companyId: number
  }
  
  export async function getAllCompanies() : Promise<CompanyListResponse>
  {
    try
    {
        const token = (await auth())?.user.authToken??'';
        let response = await apiServiceInstance.get<CompanyListResponse>({
            baseURL: SERVER_URL,
            endpoint: `${API_ENDPOINTS.companyList}`,
            headers: {
                Authorization: token
            }
        })

        if(response.data == undefined)
        {
            throw new Error('API Response Failed')
        }

        return response.data;
    }
    catch{
        throw Error('Failed')
    }
  }