import React from 'react'
import Colors from '../utils/colors'

type CustomLabelProps = {
    title: string;
};

const CustomLabel = ({ title }: CustomLabelProps) => {
  return (
    <label className="block text-sm font-medium leading-6 font-inter" style={{ color: Colors.labelColor }}>{title}</label>
  )
}

export default CustomLabel