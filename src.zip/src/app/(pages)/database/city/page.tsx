import Layout from '@/app/component/layout'
import React from 'react'

const CityScreen = () => {
  return (
    <Layout>
        <div>CityScreen</div>
    </Layout> 
  )
}

export default CityScreen