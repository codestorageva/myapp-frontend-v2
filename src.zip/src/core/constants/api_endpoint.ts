export const API_ENDPOINTS = {
    companyReg: 'company',
    companyList: 'company',
    companyDetails: 'company/',
}

export const API_DATABASE_ENDPOINT = {
    item: {
        addItem: '/product',
        allItems: '/product',
        softDelete: '/product/softDelete/',
        getSingleItem: '/product/',
        updateItem : '/product/',
        allRestoreItems: '/product',
        itemRestore: '/product/restore/'
    },
    state: {
        getAlState: '/state',
        softDelete:'/state/softDelete/',
        addState: '/state',
        updateState: '/state/',
        getSingleState:'/state/',
        allRestoreStates: '/product',
        stateRestore: '/product/restore/'
    },
    city:{
        getAllCityByStateId: '/city'
    }
}