'use client';
import { OnValueFunction } from '@/core/types';
import React, { useEffect, useState } from 'react'
import { City, fetchAllCityByStateId } from './city_controller';
import CustomSelect, { convertData, OptionData } from '@/app/component/select';

const CityDropDown = ({name, stateId, onValue, selectedCityId, labelVisible=false}: {name?: string; stateId?: string; onValue: OnValueFunction<City>; selectedCityId?: number; labelVisible: boolean}) => {
  const [cityData, setCityData] = useState<Array<OptionData<City>>>([]);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);

  useEffect(()=> {
    stateId&& getAll();
  }, 
  [selectedCityId, stateId])
  
  const getAll = async ()=>{
    if(stateId !== '')
    {
        let res =  await fetchAllCityByStateId(stateId!);

        const formattedData = res.data.map((city) => ({
            id: city.cityId,
            name: city.cityName,
            data: city
        }))
        setCityData(formattedData);

        if(selectedCityId)
        {
            let cityValue = cityData.find((e)=> e.id == selectedCityId)?.id.toString();
            setSelectedOption(cityValue ?? '');
        }
        else
        {
            setSelectedOption(null);
        }
    }
  }

    return (
        <CustomSelect
            labelVisible={false}
            className="block w-full rounded-md border focus:outline-none border-gray-300 py-2 px-2 text-gray-900 focus:border-blue-500 focus:border-[2px] placeholder:text-gray-400 sm:text-sm sm:leading-6 font-inter"
            name={name ?? 'cityId'}
            value={selectedOption ?? 'Select City'}
            option={cityData}
            onChange={(selected) => {
                onValue(convertData(selected, cityData)!, selected)
            }}
        />
  )
}

export default CityDropDown