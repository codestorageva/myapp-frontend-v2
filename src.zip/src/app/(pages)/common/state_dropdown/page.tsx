'use client'
import React, { useEffect, useState } from "react";
import { OnValueFunction } from "@/core/types";
import { fetchAllState, State } from "./state_controller";
import CustomSelect, { convertData, OptionData } from "@/app/component/select";
import { GetAllParams } from "../../items/items";
const StateDropDown = ({onValue, name, selectedStateId, selectBoxWidth, labelVisible=false} : { onValue: OnValueFunction<State>; name?: string; selectedStateId?: number; selectBoxWidth?: string; labelVisible?: boolean}) => {
 
    const [sData, setData] = useState<Array<OptionData<State>>>([]);
    const [selectedOption, setSelectedOption] = useState<string | null>(null);

    useEffect(()=> {
        getAll();
    }, [selectedStateId]);

    const getAll = async () =>{
        let res = await fetchAllState({sortBy: 'asc'} as GetAllParams);
        if(res.successCode == 'FORBIDDEN' || res.successCode == 'UNAUTHORIZED')
        {
        }
        else
        {
            const formattedData = res.data.map((state) => ({
                id: state['stateId'],
                name: state['stateName'],
                data: state
            }));
            setData(formattedData)

            if(selectedStateId)
            {
                const selectedState = formattedData.find((state)=>{
                    return state.id.toString() === selectedStateId.toString();
                });
                if(selectedState)
                {
                    setSelectedOption(selectedState.id.toString());
                }
            }
            else
            {
                setSelectedOption(null);
            }
        }
    };

    return (
        <CustomSelect
            labelVisible={false}
            className="block w-full rounded-md border focus:outline-none border-gray-300 py-2 px-2 text-gray-900 focus:border-blue-500 focus:border-[2px] placeholder:text-gray-400 sm:text-sm sm:leading-6 font-inter"
            label="State"
            name={name ?? 'stateId'}
            value={selectedOption ?? 'Select State'}
            option={sData}
            isCompulsory={true}
            onChange={(selected)=>{
                let value = convertData(selected, sData);
                onValue(value!, selected);
            }}
        />
  )
}

export default StateDropDown