export type InvoiceItem = 
{
    description: string;
    quantity: number;
    price: number;
};
export type InvoiceData = {
    invoiceNumber: string;
    date: string;
    dueDate: string;
    clientName: string;
    clientAddress: string;
    companyName: string;
    companyAddress: string;
    items: InvoiceItem[];
    taxRate: number;
    discount: number;
};

export type InvoiceDetails = {
    dueDate: string;
    invoicePrefix: string;
    invoiceNumber: string;
    companyName: string;
    date: string;
    time: string;
    clientName: string;
    address: string;
    state: string;
    city: string;
    pincode: string;
    gstNo: string;
    paymentMode: string;
    items: InvoiceProduct[];
    taxValue: string;
    gstPer: string;
    taxAmount: string;
    netAmount: string;
}

export type InvoiceProduct = {
    productName: string;
    hsnCode: string;
    qty: string;
    rate: string;
}


