'use client'
import { InvoiceDetails } from '@/app/types/invoice'
import React, { FC, useRef } from 'react'
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';


const PreviewInvoice: FC<any> = ({ invoiceData }) => {

    const invoiceRef = useRef<HTMLDivElement>(null);

    const handleDownload = async () => {
          const html2pdf = (await import('html2pdf.js')).default;

        const element = invoiceRef.current;
        if (!element) return;

        const opt = {
            margin: 0,
            filename: 'invoice.pdf',
            image: { type: 'jpeg', quality: 0.98 },
            html2canvas: { scale: 2 },
            jsPDF: { unit: 'pt', format: 'a4', orientation: 'portrait' },
        };

        html2pdf().from(element).set(opt).save();
    };

    const handleDownloadPDF = async () => {
        if (invoiceRef.current) {
            const canvas = await html2canvas(invoiceRef.current);
            const imgData = canvas.toDataURL('image/png');
            const pdf = new jsPDF('p', 'mm', 'a4');

            const pdfWidth = pdf.internal.pageSize.getWidth();
            const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

            pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
            pdf.save('invoice.pdf');
        }
    };


    return (
        <div className='w-full flex flex-col  items-center '>
            <div ref={invoiceRef} className='w-full flex flex-col  items-center my-5'>
            <div  className='w-[95%] border rounded-md items-start bg-white mb-5'>
                {/* <h2 className="text-xl font-bold mb-4 text-center">Tax Invoice</h2> */}
                <div className='flex items-stretch justify-between gap-5'>
                    <div className="w-1/3 flex justify-center items-center">
                        <img
                            src={`${window.location.origin}/globe.svg`}
                            alt="Company Logo"
                            className="h-20 w-auto object-contain"
                        />
                    </div>
                    <div className="w-2/3 border-l border-gray-300 p-5">
                        <h1 className='text-2xl font-bold'>Vaistra Technologies</h1>
                        <p>Address, City, State - Pincode</p>
                        <p><strong>GSTIN:</strong> Gst No</p>
                        <p><strong>PAN:</strong></p>
                    </div>
                </div>
                <hr />
                <div className='w-full justify-between px-2 flex'>
                    <label className='font-bold text-xl'></label>
                    <label className='font-bold text-xl'>Tax Invoice</label>
                    <label className='font-bold text-xl'>Original</label>
                </div>
                <hr />
                <div className='flex items-stretch justify-between'>
                    <div className='w-2/3  border-r p-5'>
                        <h1 className="font-semibold underline">Billed to / Shipped To Address</h1>
                        <p><strong>Name:</strong> AJAYSHIN PANWAR</p>
                        <p><strong>Address: </strong> railway station</p>
                        <p>Porbandar</p>
                        <p><strong>Phone No:</strong> 8792372436</p>
                    </div>
                    <div className="w-1/3">
                        <div className='h-[50%] p-5'>
                            <div><strong>Bill No:</strong> GSTIN1237</div>
                            <div><strong>Date:</strong> 08/04/2025</div>
                        </div>
                        <hr />
                        <div className='h-[50%] p-5'>
                            <div><strong>Payment Mode:</strong> UPI</div>
                        </div>
                    </div>

                </div>
                <table className="w-full border text-sm ">
                    <thead className="bg-gray-100">
                        <tr>
                            <th className="border px-2 py-1 text-center">#</th>
                            <th className="border px-2 py-1 text-center">Product Name</th>
                            <th className="border px-2 py-1 text-center">HSN/SAC Code</th>
                            <th className="border px-2 py-1 text-center">Qty</th>
                            <th className="border px-2 py-1 text-center">Rate</th>
                            <th className="border px-2 py-1 text-center">Taxable Value</th>
                            <th className="border px-2 py-1 text-center">GST (%)</th>
                            <th className="border px-2 py-1 text-center">CGST</th>
                            <th className="border px-2 py-1 text-center">SGST</th>
                            <th className='border px-2 py-1 text-center'>Net Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td className="border px-2 py-1 text-center">1</td>
                            <td className="border px-2 py-1">Apple 13" Macbook</td>
                            <td className="border px-2 py-1 text-right">847130</td>
                            <td className="border px-2 py-1 text-center">1</td>
                            <td className="border px-2 py-1 text-right">6864407</td>
                            <td className="border px-2 py-1 text-right">6864406</td>
                            <td className="border px-2 py-1 text-center">11%</td>
                            <td className="border px-2 py-1 text-right">6177.97</td>
                            <td className="border px-2 py-1 text-right">6177.97</td>
                            <td className="border px-2 py-1 text-right">81000.00</td>
                        </tr>
                    </tbody>
                    {/* <tbody>
                        {data.items.map((item, idx) => {
                            const taxable = item.quantity * item.price;
                            const tax = taxable * 0.18;
                            const total = taxable + tax;
                            return (
                                <tr key={idx}>
                                    <td className="border px-2 py-1 text-center">{idx + 1}</td>
                                    <td className="border px-2 py-1">{item.description}</td>
                                    <td className="border px-2 py-1">{item.hsn || ''}</td>
                                    <td className="border px-2 py-1 text-center">{item.quantity}</td>
                                    <td className="border px-2 py-1 text-right">{item.price}</td>
                                    <td className="border px-2 py-1 text-right">{taxable.toFixed(2)}</td>
                                    <td className="border px-2 py-1 text-center">18%</td>
                                    <td className="border px-2 py-1 text-right">{tax.toFixed(2)}</td>
                                    <td className="border px-2 py-1 text-right">{total.toFixed(2)}</td>
                                </tr>
                            );
                        })}
                    </tbody> */}
                </table>
                <div className="grid grid-cols-3 border">
                    <div className="col-span-2 border-r">
                        <div className='px-5 py-2'>
                            <div><strong>Bill Amount (in words):</strong> Eightly Seven Thousand Nine Hundred Only</div>
                            <div><strong>GST Amount (in words):</strong> Thirty Thousand Four Hundred Eight</div>
                        </div>
                        <hr/>
                        <div className='px-5 py-2'>
                            <div><strong>Bank Name:</strong> HDFC BANK LIMITED</div>
                            <div><strong>Bank A/c No:</strong> 50200042187917</div>
                            <div><strong>RTGS/IFSC Code:</strong> HDC0000274</div>
                        </div>
                    </div>
                    <div className="col-span-1 py-2">
                        <div className='px-5'>
                            <div className="flex justify-between"><strong>Total Taxable value:</strong><strong>74491.52</strong></div>
                            <div className="flex justify-between"><label>CGST</label>6704.24</div>
                            <div className="flex justify-between"><label>SGST</label>6704.24</div>
                        </div>
                        <hr />
                        <div className='px-5 py-2'>
                            <div className="flex justify-between"><strong>Total Invoice Value:</strong><strong>87900.00</strong></div>
                        </div>
                    </div>
                </div>
                <hr />
                <div className="flex justify-between px-5 py-3">
                    <h2 className="font-bold">Terms & Condition :</h2>
                    <h2 className="font-bold">FOR, INFINITE IT SOLUTIONS & SERVICES</h2>
                </div>
                <div className='px-5'>
                    <ol>
                        <li>1. Goods Once Sold Will Not Be Accepted.</li>
                        <li>2. All Product come with manufacturer's warranty.</li>
                        <li>3. Warranty As per their manufacturer's Terms & Conditions.</li>
                        <li>4. Physical Damage, Burnt parts or Liquid damage are not covered in warranty.</li>
                        <li>5. Any kinds of Software or compibility issues are not covered in warranty.</li>
                        <li>6. Goods Remain Property of seller till Completion of full payment.</li>
                    </ol>
                </div>
                <div className="flex justify-between items-center px-5 py-3">
                    <div className="font-semibold">
                        Receiver’s Signature :- <span className="border-b border-black inline-block w-48 ml-2" />
                    </div>
                    <div className="italic">(Authorised Signatory)</div>
                </div>
            </div>
            </div>
            <button onClick={handleDownload} className="my-4 px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Download PDF
            </button>
        </div >
    )
}

export default PreviewInvoice