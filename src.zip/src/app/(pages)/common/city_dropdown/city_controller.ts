'use server';
import { SERVER_URL } from "@/core/constants";
import { API_DATABASE_ENDPOINT } from "@/core/constants/api_endpoint";
import axios from "axios";
import { auth } from "../../../../../auth";

export interface CityResponse{
    success: boolean;
    successCode: string;
    message: string;
    pageNumber: number;
    pageSize: number;
    totalElements: number;
    totalPages: number;
    isLastPage: boolean;
    data: City[];
}

export interface City{
    cityId: number;
    cityName: string;
    stateId: number;
    stateName: string;
    countryId: number;
    countryName: string;
    status: boolean;
    isDeleted: boolean;
    createAt: string;
    updatedAt: string;
    deletedAt: string;
}

export async function fetchAllCityByStateId(stateId: string): Promise<CityResponse>{
    try{
        let response = await axios.get<CityResponse>(`${SERVER_URL}${API_DATABASE_ENDPOINT.city.getAllCityByStateId}?stateId=${stateId}`, {
            headers:{
                Authorization: (await auth())?.user.authToken??''
            }
        });

        if(response.data == undefined)
        {
            throw Error('City Response Failed');
        }
        return response.data;
    }
    catch{
        throw Error('Failure')
    }
}