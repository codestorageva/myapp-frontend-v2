'use client'
import CustomButton from '@/app/component/buttons/page';
import HeaderComponent from '@/app/component/Header-main';
import Layout from '@/app/component/layout';
import OrganizationCard from '@/app/component/organization-card/page';
import Colors from '@/app/utils/colors';
import { faPlus } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { useRouter } from 'next/navigation';
import React, { useEffect, useState } from 'react';
import { FaUserCircle } from 'react-icons/fa'; // You can replace this with your avatar logic
import { CompanyData, getAllCompanies } from './company-list';

const MainDashboard = () => {
  const router = useRouter();
  const [companyData, setCompanyData] = useState<CompanyData[]>([]);
  const [loading, setIsLoading] = useState(false);

  useEffect(()=>{
    get();
  },[])

  const get = async()=>{
    console.log("Refresh =================> ")
    try{
      setIsLoading(true)
      const res = await getAllCompanies();
      setIsLoading(false)
      console.log("Response ====> ", res)
      if(res.success)
      {
        setCompanyData(res.data)
      }
      else
      {
        alert('Something went wrong!')
      }
    }
    catch(e)
    {
      console.log(e)
    }
    finally{
      setIsLoading(false)
    }
  }

  const orgData = [
    {
      id: '60040054941',
      name: 'abcdd',
      isDefault: true,
      createdAt: '17/04/2025',
      edition: 'India',
      role: 'admin',
    },
    {
      id: '60040054942',
      name: 'SuperOrg',
      isDefault: false,
      createdAt: '01/03/2024',
      edition: 'India',
      role: 'viewer',
    },
    // Add more as needed
  ];

  return (
   <Layout showSidebar={false}>
      <div className="p-4 sm:px-10">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Welcome, </h2>
            <p className="text-sm text-gray-500 mt-1 max-w-xl">
              You are a part of the following organizations. Go to the organization which you wish to access now.
            </p>
          </div>
          {/* <button className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-blue-700 transition font-inter">
            + New Organization
          </button> */}
          <CustomButton name='New Organization' className="text-white px-4 py-2 rounded-lg text-sm hover:bg-blue-700 transition font-inter" style={{ background: `linear-gradient(to right, ${Colors.gradient1}, ${Colors.gradient2})` }} icon={<FontAwesomeIcon icon={faPlus}/>} onClick={()=> router.push('/company-registration')}/>
          
        </div>

        <h3 className="text-md font-semibold text-gray-800 mb-3">
          My Organizations{' '}
          <span className="ml-2 bg-gray-200 text-gray-600 text-xs px-2 py-0.5 rounded-full">
            {companyData.length}
          </span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {companyData.map((org) => (
            <OrganizationCard key={org.companyId} data={org} />
          ))}
        </div>
    </div>
   </Layout>
  );
};

export default MainDashboard;
