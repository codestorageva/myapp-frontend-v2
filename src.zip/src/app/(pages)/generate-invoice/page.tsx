'use client'
import TextField from '@/app/component/inputfield'
import CustomLabel from '@/app/component/label'
import Layout from '@/app/component/layout'
import { InvoiceData, InvoiceDetails, InvoiceProduct } from '@/app/types/invoice'
import { faGear, faTrash } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import React, { useEffect, useState } from 'react'
import PreviewInvoice from '../view-invoice/page'
import { InvoiceIDModel } from '@/app/component/invoice_prefix_model.tsx'


const GenerateInvoice = () => {
    const [state, setStateName] = useState('')
    const [city, setCityName] = useState('')
    const states = ['Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh', 'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jharkhand', 'Karnataka', 'Kerala', 'Madhya Pradesh']
    const cities = ['Ahmedabad', 'Surat', 'Baroda', 'Rajkot', 'Bhavnagar', 'Jamnagar', 'Junagadh', 'Gandhinagar', 'Porbandar', 'Morbi', 'Nadiad', 'Bharuch', 'Vapi', 'Ankleshwar', 'Patan', 'Mehsana', 'Bhuj', 'Palanpur', 'Veraval', 'Surendranagar']
    const paymentMode = ['Online', 'Case', 'Banking']
    const companies = ['Vaistra Texhnologies']
    const terms = ['Net 45', 'Net 60', 'Due On Receipt', 'Due end of the month', 'Due end of the next month', 'Custom']
    const [term, setTerm] = useState('Due On Receipt')
    const [showInvoice, setShowInvoice] = useState(false);
    const today = new Date().toISOString().split('T')[0];
    const dueDate = new Date().toISOString().split('T')[0];
    const [invoiceData, setInvoiceData] = useState<InvoiceDetails>({ dueDate: dueDate, invoicePrefix: 'VV', invoiceNumber: '000001', companyName: '', date: today, time: '', clientName: '', address: '', city: '', gstNo: '', gstPer: '', items: [{ productName: '', hsnCode: '', qty: '0', rate: '' }], netAmount: '', paymentMode: '', pincode: '', state: '', taxAmount: '', taxValue: '' })
    const formatDate = (date: Date) => date.toISOString().split('T')[0];
    const [isModalOpen, setIsModalOpen] = useState(false);

    useEffect(() => {
        const invoiceDate = new Date(invoiceData.date);
        let dueDT = new Date(invoiceDate);

        switch (term) {
            case 'Net 45':
                dueDT.setDate(invoiceDate.getDate() + 45);
                break;
            case 'Net 60':
                dueDT.setDate(invoiceDate.getDate() + 60);
                break;
            case 'Due end of the month':
                dueDT = new Date(Date.UTC(invoiceDate.getFullYear(), invoiceDate.getMonth() + 1, 0));
                break;
            case 'Due end of the next month':
                dueDT = new Date(Date.UTC(invoiceDate.getFullYear(), invoiceDate.getMonth() + 2, 0));
                break;
            case 'Due On Receipt':
                dueDT = invoiceDate;
                break;
            case 'Custom':
                return;
        }

        setInvoiceData((prev) => ({ ...prev, dueDate: formatDate(dueDT) }))

    }, [term, invoiceData.date])

    const handleClose = () => {
        setIsModalOpen(false);
    };

    return (
        <Layout>
            <div className='w-full flex flex-col  items-center'>

                <h1 className="text-3xl font-bold text-center text-black mb-10">Generate Invoice</h1>
                <div className='w-[95%] border rounded-md items-start bg-white p-5 mb-5'>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">

                        {/* <TextField label='Invoice #' type='text' value={invoiceData.invoiceNumber} onChange={(e)=> { setInvoiceData({...invoiceData, invoiceNumber: e.target.value})}}/> */}
                        <div className="w-full col-span-1 md:col-span-1">
                            <CustomLabel title="Invoice #" />
                            <div className="flex gap-2">
                                <div className="w-[25%]">
                                    <TextField
                                        placeholder="Prefix"
                                        value={invoiceData.invoicePrefix}
                                        onChange={(e) =>
                                            setInvoiceData({ ...invoiceData, invoicePrefix: e.target.value })
                                        }
                                    />
                                </div>
                                <div className="w-[75%] relative">
                                    <TextField
                                        placeholder="Number"
                                        value={invoiceData.invoiceNumber}
                                        onChange={(e) =>
                                            setInvoiceData({ ...invoiceData, invoiceNumber: e.target.value })
                                        }
                                        className="pr-10"
                                    />
                                    <button
                                        type="button"
                                        onClick={() => { }} // your modal function
                                        className="absolute inset-y-0 right-2 flex items-center justify-center text-gray-500 hover:text-blue-600"
                                        title="Configure Invoice Number"
                                    >
                                        <FontAwesomeIcon icon={faGear} className="w-4 h-4" />
                                    </button>
                                </div>
                            </div>
                        </div>
                        {/* <div className="sm:col-span-1">
                            <CustomLabel title='Company Name' />
                            <div className="relative w-full mt-1">
                                <select
                                    value={invoiceData.companyName}
                                    onChange={(e) => {
                                        setInvoiceData({ ...invoiceData, companyName: e.target.value })
                                    }}
                                    className="block w-full rounded-md border focus:outline-none border-gray-300 py-2 px-2 text-gray-900 focus:border-blue-500 focus:border-[2px] placeholder:text-gray-400 sm:text-sm sm:leading-6 font-inter"
                                >
                                    <option value="">Select Company</option>
                                    {companies.map((company: string, index: number) => (
                                        <option key={index} value={company}>
                                            {company}
                                        </option>
                                    ))}
                                </select>
                            </div>

                        </div> */}
                        <TextField label='Invoice Date' type='date' value={invoiceData.date} onChange={(e) => { setInvoiceData({ ...invoiceData, date: e.target.value }) }} />
                        {/* <TextField label='Time' type='time' value={invoiceData.time} onChange={(e) => { setInvoiceData({ ...invoiceData, time: e.target.value }) }} /> */}
                        <div className="sm:col-span-1">
                            <CustomLabel title='Term' />
                            <div className="relative w-full mt-1">
                                <select
                                    value={term}
                                    onChange={(e) => { setTerm(e.target.value) }}

                                    name='term'
                                    className="block w-full rounded-md border focus:outline-none border-gray-300 py-2 px-2 text-gray-900 focus:border-blue-500 focus:border-[2px] placeholder:text-gray-400 sm:text-sm sm:leading-6 font-inter"
                                >
                                    <option value="">Select Term</option>
                                    {terms.map((term: string, index: number) => (
                                        <option key={index} value={term}>
                                            {term}
                                        </option>
                                    ))}
                                </select>
                            </div>
                        </div>
                        <TextField label='Due Date' type='date' value={invoiceData.dueDate} onChange={(e) => { setInvoiceData({ ...invoiceData, dueDate: e.target.value }) }} />
                        <TextField label='Customer Name' type='text' value={invoiceData.clientName} onChange={(e) => { setInvoiceData({ ...invoiceData, clientName: e.target.value }) }} />
                        <TextField label='Address' type='multiline' value={invoiceData.address} onChange={(e) => { setInvoiceData({ ...invoiceData, address: e.target.value }) }} />
                        <div className="sm:col-span-1">
                            <CustomLabel title='State' />
                            <div className="relative w-full mt-1">
                                <select
                                    value={invoiceData.state}
                                    onChange={(e) => {
                                        setInvoiceData({ ...invoiceData, state: e.target.value })
                                    }}
                                    className="block w-full rounded-md border focus:outline-none border-gray-300 py-2 px-2 text-gray-900 focus:border-blue-500 focus:border-[2px] placeholder:text-gray-400 sm:text-sm sm:leading-6 font-inter"
                                >
                                    <option value="">Select State</option>
                                    {states.map((state: string, index: number) => (
                                        <option key={index} value={state}>
                                            {state}
                                        </option>
                                    ))}
                                </select>
                            </div>

                        </div>
                        <div className="sm:col-span-1">
                            <CustomLabel title='City' />
                            <div className="relative w-full mt-1">
                                <select
                                    value={invoiceData.city}
                                    onChange={(e) => {
                                        setInvoiceData({ ...invoiceData, city: e.target.value })
                                    }}
                                    className="block w-full rounded-md border focus:outline-none border-gray-300 py-2 px-2 text-gray-900 focus:border-blue-500 focus:border-[2px] placeholder:text-gray-400 sm:text-sm sm:leading-6 font-inter"
                                >
                                    <option value="">Select City</option>
                                    {cities.map((city: string, index: number) => (
                                        <option key={index} value={city}>
                                            {city}
                                        </option>
                                    ))}
                                </select>
                            </div>

                        </div>
                        <TextField label='Pincode' type='number' value={invoiceData.pincode} onChange={(e) => { setInvoiceData({ ...invoiceData, pincode: e.target.value }) }} />
                        <TextField label='GST Number' type='number' value={invoiceData.gstNo} onChange={(e) => { setInvoiceData({ ...invoiceData, gstNo: e.target.value }) }} />
                        <div className="sm:col-span-1">
                            <CustomLabel title='Payment Mode' />
                            <div className="relative w-full mt-1">
                                <select
                                    value={invoiceData.paymentMode}
                                    onChange={(e) => {
                                        setInvoiceData({ ...invoiceData, paymentMode: e.target.value })
                                    }}
                                    className="block w-full rounded-md border focus:outline-none border-gray-300 py-2 px-2 text-gray-900 focus:border-blue-500 focus:border-[2px] placeholder:text-gray-400 sm:text-sm sm:leading-6 font-inter"
                                >
                                    <option value="">Select Payment Mode</option>
                                    {paymentMode.map((mode: string, index: number) => (
                                        <option key={index} value={mode}>
                                            {mode}
                                        </option>
                                    ))}
                                </select>
                            </div>

                        </div>

                    </div>
                    <div className="space-y-4 mt-6">
                        <div className="flex justify-between items-center">
                            <h3 className="text-lg font-semibold text-gray-700 font-inter">Invoice Items</h3>
                            <button
                                type="button"
                                onClick={() => setInvoiceData((prev) => ({
                                    ...prev,
                                    items: [
                                        ...prev.items,
                                        { productName: "", hsnCode: "", qty: "", rate: "" }
                                    ]
                                }))}
                                className="px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded hover:bg-blue-700 font-inter"
                            >
                                + Add Item
                            </button>
                        </div>

                        {invoiceData.items.map((item: InvoiceProduct, index: number) => (
                            <div
                                key={index}
                                className="relative bg-gray-50 p-4 rounded-lg border mb-4"
                            >
                                <button
                                    type="button"
                                    // onClick={() => remove(index)}
                                    onClick={() => {
                                        const updateItems = [...invoiceData.items];
                                        updateItems.splice(index, 1);
                                        setInvoiceData({ ...invoiceData, items: updateItems });
                                    }}
                                    className="absolute top-3 right-3 text-red-500 hover:text-red-700"
                                    title="Remove item"
                                >
                                    <FontAwesomeIcon icon={faTrash} className="w-4 h-4" />
                                </button>
                                <div className="grid grid-cols-1 md:grid-cols-4 gap-5 items-end">
                                    <TextField label="Product Name" type="text" value={item.productName} onChange={(e) => {
                                        const updateItems = [...invoiceData.items];
                                        updateItems[index].productName = e.target.value;
                                        setInvoiceData({ ...invoiceData, items: updateItems });
                                    }} />
                                    <TextField label="HSN/SAC Code" type="text" value={item.hsnCode} onChange={(e) => {
                                        const updateItems = [...invoiceData.items];
                                        updateItems[index].hsnCode = e.target.value;
                                        setInvoiceData({ ...invoiceData, items: updateItems });
                                    }} />
                                    <TextField label="Quantity" type="number" value={item.qty} onChange={(e) => {
                                        const updateItems = [...invoiceData.items];
                                        updateItems[index].qty = e.target.value;
                                        setInvoiceData({ ...invoiceData, items: updateItems });
                                    }} />
                                    <TextField label="Rate" type="number" value={item.rate} onChange={(e) => {
                                        const updateItems = [...invoiceData.items];
                                        updateItems[index].rate = e.target.value;
                                        setInvoiceData({ ...invoiceData, items: updateItems });
                                    }} />
                                </div>
                            </div>
                        ))}

                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-5">
                        <TextField label='Tax Value' type='text' value={invoiceData.taxValue} onChange={(e) => { setInvoiceData({ ...invoiceData, taxValue: e.target.value }) }} />
                        <TextField label='GST' type='text' value={invoiceData.gstPer} onChange={(e) => { setInvoiceData({ ...invoiceData, gstPer: e.target.value }) }} />
                        <TextField label='Tax Amount' type='text' value={invoiceData.taxAmount} onChange={(e) => { setInvoiceData({ ...invoiceData, taxAmount: e.target.value }) }} />
                        <TextField label='Net Amount' type='text' value={invoiceData.netAmount} onChange={(e) => { setInvoiceData({ ...invoiceData, netAmount: e.target.value }) }} />
                    </div>
                    <div className="mt-10 w-full flex items-center justify-center gap-5">
                        <button type="submit" className="w-full md:w-auto bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg font-medium font-inter shadow-lg">
                            Generate
                        </button>
                        <button type="submit" className="w-full md:w-auto  bg-[#03508C] text-white hover:bg-[#0874CB] px-6 py-2 rounded-lg font-medium font-inter transition-colors shadow-lg">
                            Cancel
                        </button>
                    </div>
                    
                </div>
            </div>

            {/* <PreviewInvoice invoiceData={invoiceData} /> */}
        </Layout>
    )
}

export default GenerateInvoice